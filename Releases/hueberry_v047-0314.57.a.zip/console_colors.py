#!/usr/bin/env python

class bcolors:
    PRPL = '\033[95m'
    BLU = '\033[94m'
    GRN = '\033[92m'
    YLO = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
